import json
import logging
import pprint
import sys
import time
import warnings

import googleapiclient.discovery
import googleapiclient.errors
from google.auth._default import _CLOUD_SDK_CREDENTIALS_WARNING

from . import cmdline


logger = logging.getLogger('gce-v2v')
info = logger.info
warning = logger.warning
error = logger.error

# Warning when using Cloud SDK user credentials
# Disable it since we do want to use our user credentials for local testing
warnings.filterwarnings('ignore', message=_CLOUD_SDK_CREDENTIALS_WARNING)
compute = googleapiclient.discovery.build('compute', 'v1')


def _init_logger():
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    fmt = '%(asctime)s %(levelname).1s %(name)s - %(message)s'
    time_fmt = '%Y-%m-%d %H:%M:%S'
    formatter = logging.Formatter(fmt, time_fmt)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(formatter)
    root_logger.addHandler(ch)


def _set_logger_verbosity(verbose):
    if verbose > 0:
        global_log_level = logging.DEBUG
    else:
        global_log_level = logging.INFO
    logger.setLevel(global_log_level)


def _wait_for_operation(args, operation, timeout=300):
    operation_name = operation['name']
    start_time_sec = time.time()
    while time.time() - start_time_sec < timeout:
        result = compute.zoneOperations().get(
            project=args.project,
            zone=args.zone,
            operation=operation_name
        ).execute()

        if result['status'] == 'DONE':
            if 'error' in result:
                raise RuntimeError(result['error'])
            return

        time.sleep(10)

    raise RuntimeError(f'timeout waiting on operation {operation_name}')


def _get_serial_port_output(args, instance, port, start):
    try:
        response = compute.instances().getSerialPortOutput(
            project=args.project, zone=args.zone,
            instance=instance, port=port,
            start=start
        ).execute()
    except googleapiclient.errors.HttpError as e:
        warning(f'getSerialPortOutput failed with: {e}')
        return None, None
    contents = response.get('contents')
    if not contents:
        return None, None
    return contents, response['next']


def _print_title_line(title_line):
    centered_title_line = f' {title_line} '.center(100, '-')
    bold_title_line = f'\x1B[1m{centered_title_line}\x1B[0m'
    sys.stdout.write(f'{bold_title_line}\n')


def _wait_for_instance(args, instance, query_path, port=None, timeout=600):
    start_time_sec = time.time()
    next_pos = '0'
    contents_printed = False
    contents_endswith_newline = False
    result = None
    while time.time() - start_time_sec < timeout:
        if port:
            contents, new_next_pos = _get_serial_port_output(
                args, instance, port, next_pos
            )
            if contents:
                if not contents_printed:
                    _print_title_line(f'{instance} - serial port {port}:')
                    contents_printed = True
                sys.stdout.write(contents)
                contents_endswith_newline = contents.endswith('\n')
                next_pos = new_next_pos
        try:
            result = compute.instances().getGuestAttributes(
                project=args.project, zone=args.zone,
                instance=instance, queryPath=query_path
            ).execute()
            result = result['queryValue']['items'][0]['value']
            break
        except googleapiclient.errors.HttpError as e:
            if e.resp.status == 503:
                # Allow transient "internal error" failures
                pass
            elif e.resp.status == 404 and query_path in str(e):
                # Allow "not found" errors only if it involves the query
                # path
                pass
            else:
                raise
        time.sleep(30)

    if contents_printed:
        if not contents_endswith_newline:
            sys.stdout.write('\n')
        _print_title_line(f'{instance} - serial port {port} end')

    return result


def _delete_instance(args, instance_name):
    info(f'Deleting instance {instance_name}')
    try:
        operation = compute.instances().delete(
            project=args.project, zone=args.zone,
            instance=instance_name
        ).execute()
        _wait_for_operation(args, operation)
    except googleapiclient.errors.Error as e:
        warning(f'Could not delete instance {instance_name}: {e}')


def _v2v(args, additional_argv, disk_names):

    info(f'Creating adaptation vm: {args.v2v_instance_name}')

    if args.verbose > 1:
        v2v_log_level = 'trace'
    elif args.verbose == 1:
        v2v_log_level = 'debug'
    else:
        v2v_log_level = 'info'

    docker_command = ('docker run --privileged -v '
                      '/dev/disk/by-id:/dev/disk/by-id:ro')
    report_path = 'v2v/report'
    md_report_file = (
        f'http://metadata.google.internal/computeMetadata/v1/'
        f'instance/guest-attributes/{report_path}'
    )
    startup_script = (
        f'{docker_command} v2v -vv '
        f'--log file=/dev/ttyS2,level={v2v_log_level} '
        f'--report file=/dev/ttyS3 '
        f'--report file={md_report_file},headers=Metadata-Flavor=Google '
        f'--in-place '
    ) + ''.join(
        [(f'--drive file=/dev/disk/by-id/google-workload-disk{i+1},'
          f'format=raw ') for i in range(len(disk_names))]
    ) + ' '.join(additional_argv) + ' >/dev/ttyS2 2>&1'

    config = {
        'name': args.v2v_instance_name,
        'machineType':
            f'projects/{args.project}/zones/{args.zone}/machineTypes/'
            f'{args.v2v_machine_type}',

        'disks': [{
            'boot': True,
            'initializeParams': {
                'sourceImage': args.v2v_image
            },
            'autoDelete': True
        }] + [{
            'source': (f'projects/{args.project}/zones/{args.zone}/'
                       f'disks/{vm_disk_name}'),
            'deviceName': f'workload-disk{i+1}',
            'autoDelete': False
        } for i, vm_disk_name in enumerate(disk_names)],
        'networkInterfaces': [{
            'network': args.network,
            'subnetwork': args.subnet
        }],
        'metadata': {
            'items': [{
                'key': 'block-project-ssh-keys',
                'value': 'true'
            }, {
                'key': 'enable-guest-attributes',
                'value': 'true'
            }, {
                'key': 'startup-script',
                'value': startup_script
            }]
        }
    }

    operation = compute.instances().insert(
        project=args.project, zone=args.zone, body=config
    ).execute()

    _wait_for_operation(args, operation)

    try:
        result = _wait_for_instance(
            args, args.v2v_instance_name, report_path, port=3,
            timeout=args.v2v_timeout
        )
        if not result:
            return None
        report = json.loads(result)
        _print_title_line('Adaptation report')
        pprint.pprint(report)
        _print_title_line('Adaptation report end')
    finally:
        _delete_instance(args, args.v2v_instance_name)

    return report


def _clone_disk(args, source_disk_name, target_disk_name,
                guest_os_features=None, licenses=None):
    config = {
        'name': target_disk_name,
        'sourceDisk': f'zones/{args.zone}/disks/{source_disk_name}',
        'description': f'source: f{source_disk_name}',
        'guestOsFeatures': [{'type': f} for f in (guest_os_features or [])],
        'licenses': (licenses or [])
    }
    operation = compute.disks().insert(
        project=args.project, zone=args.zone, body=config
    ).execute()
    _wait_for_operation(args, operation)


def _delete_disk(args, disk_name):
    try:
        operation = compute.disks().delete(
            project=args.project, zone=args.zone, disk=disk_name
        ).execute()
        _wait_for_operation(args, operation)
    except googleapiclient.errors.Error as e:
        warning(f'Could not delete disk {disk_name}: {e}')


def _get_new_guest_os_features_and_licenses(project, zone, disk,
                                            guest_os_features,
                                            licenses):
    disk_info = compute.disks().get(project=project,
                                    zone=zone,
                                    disk=disk).execute()
    current_guest_os_features = disk_info.get('guestOsFeatures', [])
    current_licenses = set(disk_info.get('licenses', []))
    current_guest_os_features = {f['type'] for f in current_guest_os_features}
    return (list(set(guest_os_features) - current_guest_os_features),
            list(set(licenses) - current_licenses))


# pylint: disable=too-many-branches
def main():

    _init_logger()

    args, additional_argv = cmdline.parse()

    _set_logger_verbosity(args.verbose)

    boot_disk = next((disk for disk in args.disks if disk.boot))

    if args.clone_disks:
        for disk in args.disks:
            info(f'Cloning disk: {disk.name} -> {disk.clone_name}')
            _clone_disk(args, disk.name, disk.clone_name)
        disk_names = [disk.clone_name for disk in args.disks]
        boot_disk_name = boot_disk.clone_name
    else:
        disk_names = [disk.name for disk in args.disks]
        boot_disk_name = boot_disk.name

    non_boot_disk_names = [name for name in disk_names
                           if name != boot_disk_name]

    report = _v2v(args, additional_argv, disk_names)
    if report is None:
        error('Timeout waiting for adaptation vm')
        return 1

    for report_arg in (args.reports or []):
        with open(report_arg.file, 'w') as f:
            json.dump(report, f)

    if report['status'] != 'SUCCESS':
        error('Failed adapting disks')
        return 1

    guest_os_features = report['guest_os_features']
    licenses = report['licenses']

    (guest_os_features, licenses) = _get_new_guest_os_features_and_licenses(
        args.project, args.zone, boot_disk_name,
        guest_os_features, licenses
    )

    if not args.no_recreate_boot_disk:
        if not guest_os_features and not licenses:
            info('No need to recreate the boot disk - no new guestOsFeatures '
                 'or licenses')
        else:
            info(f'Recreating boot disk: '
                 f'{boot_disk_name} -> {args.new_boot_disk_name}')
            _clone_disk(args, boot_disk_name, args.new_boot_disk_name,
                        guest_os_features=guest_os_features,
                        licenses=licenses)
            if args.clone_disks:
                # We delete the source disk only if it is a clone created by
                # us - do not delete supplied disks when adapting in place
                info(f'Deleting intermediate cloned boot disk: '
                     f'{boot_disk_name}')
                _delete_disk(args, boot_disk_name)
            boot_disk_name = args.new_boot_disk_name
    else:
        if guest_os_features or licenses:
            warning('Boot disk must be recreated in order to add missing '
                    'guestOsFeatures and licenses')
            for missing_feature in guest_os_features:
                warning(f'Missing guestOsFeature: {missing_feature}')
            for missing_license in licenses:
                warning(f'Missing license: {missing_license}')

    info('Adaptation completed successfully')

    info('Boot disk:')
    info(f'* {boot_disk_name}')
    if non_boot_disk_names:
        info('Additional disks:')
        for disk_name in non_boot_disk_names:
            info(f'* {disk_name}')
    return 0
