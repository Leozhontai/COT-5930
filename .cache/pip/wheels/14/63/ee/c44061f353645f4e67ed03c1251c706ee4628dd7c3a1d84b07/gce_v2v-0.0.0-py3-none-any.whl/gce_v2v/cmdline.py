import argparse
import os
import random
import string
import sys
import logging
from typing import Optional

logger = logging.getLogger('gce-v2v')
warning = logger.warning


def _random_lowercase(n):
    return ''.join(random.choice(string.ascii_lowercase) for _ in range(n))


def _fill_random_letters(s):
    return ''.join([c if c != '?' else _random_lowercase(1)
                    for c in s])


def _new_disk_name(name, suffix):
    # Must follow regular expression [a-z]([-a-z0-9]*[a-z0-9])?
    # and not exceed a max length of 63 characters
    max_disk_name_len = 63
    new_name = name[:max_disk_name_len - len(suffix)]
    new_name = f'{new_name}{suffix}'
    return new_name


def _create_parts(params, join_str):
    parts = []
    for k, (_, v) in params.items():
        if v:
            parts.append(f'{k}={v}')
        else:
            parts.append(f'{k}')
    return join_str.join(parts)


def _create_metavar(required, optional):
    required_str = _create_parts(required, ',')
    optional_str = _create_parts(optional, '][,')
    metavar_str = required_str
    if optional_str:
        metavar_str += '[,' + optional_str + ']'
    return metavar_str


def _parse_values(values):
    params = values.split(',')
    parsed_values = dict()
    for param in params:
        tup = param.split('=', maxsplit=1)
        if len(tup) == 1:
            k, = tup
            v = True
        else:
            assert len(tup) == 2
            k, v = tup
        parsed_values[k] = v
    return parsed_values


class _MultiParamParser:

    @staticmethod
    def name():
        raise NotImplementedError

    @staticmethod
    def help():
        raise NotImplementedError

    @staticmethod
    def required():
        raise NotImplementedError

    @staticmethod
    def optional():
        return {}

    @classmethod
    def metavar(cls):
        return _create_metavar(cls.required(), cls.optional())

    @classmethod
    def missing(cls, parser: argparse.ArgumentParser, param):
        parser.error(f'Missing {cls.name()} required parameter: '
                     f'{param}')

    @classmethod
    def parse_params(cls, parser, params, options):
        required = list(cls.required().keys())
        for k, v in params.items():
            if k in cls.required():
                if k in required:
                    required.remove(k)
                var_name, _ = cls.required()[k]
            elif k in cls.optional():
                var_name, _ = cls.optional()[k]
            else:
                parser.error(f'Unknown {cls.name()} parameter {k}')
                assert False  # noreturn
            assert hasattr(options, var_name)
            setattr(options, var_name, v)
        if len(required) > 0:
            cls.missing(parser, required[0])


class ReportOptions:

    def __init__(self):
        self.file: Optional[str] = None


class _ReportParser(_MultiParamParser, argparse.Action):

    @staticmethod
    def name():
        return '--report'

    @staticmethod
    def help():
        return ('Supply path to output the adaptation report. '
                'Multiple report files are supported')

    @staticmethod
    def required():
        return {
            'file': ('file', 'PATH')
        }

    def __call__(self, parser, namespace, values, option_string=None):
        params = _parse_values(values)
        options = ReportOptions()
        self.parse_params(parser, params, options)
        if not options.file:
            parser.error(f'No file name supplied for {self.name()}')

        prev = getattr(namespace, self.dest, None)
        if not prev:
            prev = list()
        prev.append(options)
        setattr(namespace, self.dest, prev)


class DiskOptions:

    def __init__(self):
        self.name = None
        self.boot = False
        self.clone_name = None


class _DiskParser(_MultiParamParser, argparse.Action):

    NAME_METAVAR = 'NAME'
    DEFAULT_CLONE_NAME_SUFFIX = '-??????'
    DEFAULT_CLONE_NAME = f'{NAME_METAVAR}{DEFAULT_CLONE_NAME_SUFFIX}'

    @staticmethod
    def name():
        return '--disk'

    @staticmethod
    def help():
        return (f'Supply disk information, multiple disks are supported. '
                f'If cloning disks, clone-name will be used as the new disk '
                f'name. Question marks ("?") will be converted to random '
                f'letters. '
                f'[default: {_DiskParser.DEFAULT_CLONE_NAME}]')

    @staticmethod
    def required():
        return {
            'name': ('name', _DiskParser.NAME_METAVAR),
        }

    @staticmethod
    def optional():
        return {
            'boot': ('boot', None),
            'clone-name': ('clone_name', _DiskParser.DEFAULT_CLONE_NAME)
        }

    def __call__(self, parser, namespace, values, option_string=None):
        params = _parse_values(values)
        options = DiskOptions()
        self.parse_params(parser, params, options)

        if not options.clone_name:
            new_name = _new_disk_name(options.name,
                                      _DiskParser.DEFAULT_CLONE_NAME_SUFFIX)
            new_name = _fill_random_letters(new_name)
            options.clone_name = new_name

        prev = getattr(namespace, self.dest, None)
        if not prev:
            prev = list()
        prev.append(options)
        setattr(namespace, self.dest, prev)


# pylint: disable=too-many-statements
def parse():
    argv = sys.argv[1:]
    if '--' in argv:
        split_index = argv.index('--')
        additional_argv = argv[split_index + 1:]
        argv = argv[:split_index]
    else:
        additional_argv = []

    default_project = os.getenv('DEVSHELL_PROJECT_ID', '')
    if not default_project:
        default_project = os.getenv('V2V_GCP_PROJECT', '')

    default_v2v_image = os.getenv('V2V_GCP_V2V_IMAGE', '')

    default_v2v_instance_name = 'v2v-??????'

    default_v2v_machine_type = 'n1-standard-2'

    default_v2v_timeout = 600

    default_boot_disk_suffix = '-boot-??????'

    parser = argparse.ArgumentParser(
        description='gcp-v2v converts persistent disks from a foreign '
                    'hypervisor to run on Google Cloud Platform'
    )
    parser.add_argument('-v', '--verbose',
                        help='Specify to increase verbosity and display debug '
                             'level logs, specify twice to additionally '
                             'output adaptation VM logs',
                        action='count', default=0)
    parser.add_argument('--project',
                        help=('Project in which the adaptation VM will '
                              'run ' + (
                                  f'[default: {default_project}]'
                                  if default_project else '')
                              ),
                        action='store', type=str, default=default_project,
                        required=(not default_project))
    parser.add_argument('--zone',
                        help='Zone in which the adaptation VM will run',
                        action='store', type=str, required=True)
    parser.add_argument('--network',
                        help='Network to be used by the adaptation VM',
                        action='store', type=str, required=True)
    parser.add_argument('--subnet',
                        help='Subnetwork to be used by the adaptation VM',
                        action='store', type=str, required=True)
    parser.add_argument('--v2v-image', metavar='IMAGE_NAME',
                        help=('Adaptation VM image to use ' + (
                                  f'[default: {default_v2v_image}]'
                                  if default_v2v_image else '')
                              ),
                        action='store', type=str, default=default_v2v_image,
                        required=(not default_v2v_image))
    parser.add_argument('--v2v-instance-name', metavar='INSTANCE_NAME',
                        help=f'Instance name of the created adaptation vm. '
                             f'Question marks ("?") will be converted to '
                             f'random letters '
                             f'[default: {default_v2v_instance_name}]',
                        action='store', type=str,
                        default=default_v2v_instance_name)
    parser.add_argument('--v2v-machine-type', metavar='MACHINE_TYPE',
                        help=f'Machine type to use for the adaptation VM. '
                             f'Note that the instance type has to support '
                             f'nested virtualization '
                             f'[default: {default_v2v_machine_type}]',
                        action='store', type=str,
                        default=default_v2v_machine_type)
    parser.add_argument('--v2v-timeout', metavar='SECONDS',
                        help=f'Timeout in seconds for the adaptation process '
                             f'[default: {default_v2v_timeout}]',
                        action='store', type=int, default=default_v2v_timeout)
    parser.add_argument('--clone-disks',
                        help='Create clones of the disks before adapting and '
                             'leave the original disks unmodified',
                        action='store_true', default=False)
    parser.add_argument('--no-recreate-boot-disk',
                        help='Do not recreate the boot disk with the '
                             'additionally required licenses and '
                             'guestOsFeatures',
                        action='store_true', default=False)
    parser.add_argument('--new-boot-disk-name', metavar='DISK_NAME',
                        help=f'Unless --no-recreate-boot-disk was supplied or '
                             f'if there are no new additionally '
                             f'required licenses or guestOsFeatures, this '
                             f'will define the name of the new recreated '
                             f'boot disk. '
                             f'Question marks ("?") will be replaced with '
                             f'random letters '
                             f'[default: NAME{default_boot_disk_suffix}]',
                        action='store', type=str, default=None)
    parser.add_argument('--in-place',
                        help='Modify provided disks in place',
                        action='store_true')
    parser.add_argument(_DiskParser.name(), dest='disks',
                        metavar=_DiskParser.metavar(),
                        help=_DiskParser.help(),
                        action=_DiskParser, required=True)
    parser.add_argument(_ReportParser.name(), dest='reports',
                        metavar=_ReportParser.metavar(),
                        help=_ReportParser.help(),
                        action=_ReportParser, required=False)

    args = parser.parse_args(argv)

    boot_disk = None
    for d in args.disks:  # type: DiskOptions
        if d.boot:
            if boot_disk:
                parser.error('Can not specify "boot" option for more than one '
                             'disk')
            boot_disk = d
    if not boot_disk:
        warning('Boot disk not specified, assuming first disk')
        args.disks[0].boot = True
        boot_disk = args.disks[0]

    if not args.new_boot_disk_name:
        args.new_boot_disk_name = _new_disk_name(boot_disk.name,
                                                 default_boot_disk_suffix)
    args.new_boot_disk_name = _fill_random_letters(args.new_boot_disk_name)

    if args.in_place and args.clone_disks:
        parser.error('Can not specify --clone-disks together with --in-place')
    if not args.in_place and not args.clone_disks:
        parser.error('Must specify --clone-disks or --in-place')

    args.v2v_instance_name = _fill_random_letters(args.v2v_instance_name)

    return args, additional_argv
